(() => {
  const announce = () => window.postMessage({ type: "SRQ_EXTENSION_READY", version: chrome.runtime.getManifest().version }, "*");
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "SRQ_EXTENSION_PING") announce();
    if (event.data?.type === "SRQ_OPEN_REPORTS" && Array.isArray(event.data.reports)) {
      chrome.runtime.sendMessage({ type: "SRQ_OPEN_REPORTS", reports: event.data.reports, mode: event.data.mode === "tabs" ? "tabs" : "windows" }, (result) => {
        window.postMessage({ type: "SRQ_OPEN_RESULT", ...(result || { opened: 0, failed: event.data.reports.length }) }, "*");
      });
    }
  });
  announce();
})();

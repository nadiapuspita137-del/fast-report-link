const BASE = "https://safebrowsing.google.com/safebrowsing/report_phish/?hl=id";

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "SRQ_OPEN_REPORTS" || !Array.isArray(message.reports)) return;
  (async () => {
    let opened = 0;
    for (const report of message.reports.slice(0, 100)) {
      try {
        const target = `${BASE}&url=${encodeURIComponent(report.url)}&srq_detail=${encodeURIComponent(String(report.description || "").slice(0, 800))}`;
        if (message.mode === "tabs") {
          await chrome.tabs.create({ url: target, active: false });
        } else {
          const offset = (opened % 8) * 28;
          await chrome.windows.create({
            url: target,
            type: "normal",
            focused: false,
            width: 920,
            height: 780,
            left: 24 + offset,
            top: 24 + offset
          });
        }
        opened++;
      } catch {}
    }
    sendResponse({ opened, failed: message.reports.length - opened, mode: message.mode === "tabs" ? "tabs" : "windows" });
  })();
  return true;
});

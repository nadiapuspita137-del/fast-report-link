(() => {
  const detail = new URLSearchParams(location.search).get("srq_detail");
  let attempts = 0;
  const fire = (element) => {
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const chooseNative = (select, wanted) => {
    const option = [...select.options].find((item) => item.textContent.trim() === wanted);
    if (!option || select.value === option.value) return Boolean(option);
    select.value = option.value;
    fire(select);
    return true;
  };
  const chooseGoogleDropdown = (wanted) => {
    const option = [...document.querySelectorAll('[role="option"], [role="menuitem"]')]
      .find((item) => item.textContent.trim() === wanted);
    if (!option) return false;
    option.click();
    return true;
  };
  const selectByOrder = (index, wanted) => {
    const native = document.querySelectorAll("select")[index];
    if (native) return chooseNative(native, wanted);
    const combo = document.querySelectorAll('[role="combobox"]')[index];
    if (!combo) return false;
    if (combo.textContent.includes(wanted)) return true;
    combo.click();
    return chooseGoogleDropdown(wanted);
  };
  const timer = setInterval(() => {
    attempts++;
    const fields = [...document.querySelectorAll("textarea")].filter((el) => el.name !== "g-recaptcha-response");
    const field = fields[0];
    if (field && detail && field.value !== detail) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(field, detail);
      fire(field);
    }
    const threatReady = selectByOrder(0, "Software yang Tidak Diinginkan");
    const categoryReady = threatReady && selectByOrder(1, "Software Seluler yang Tidak Diinginkan");
    if ((field || !detail) && threatReady && categoryReady) clearInterval(timer);
    else if (attempts >= 60) clearInterval(timer);
  }, 250);
})();

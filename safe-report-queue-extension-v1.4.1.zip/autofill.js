(() => {
  const detail = new URLSearchParams(location.search).get("srq_detail");
  let attempts = 0;
  let filling = false;
  const fire = (element) => {
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const chooseNative = (select, wanted) => {
    const option = [...select.options].find((item) => item.textContent.trim() === wanted);
    if (!option || select.value === option.value) return Boolean(option);
    select.value = option.value;
    fire(select);
    return true;
  };
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const chooseGoogleDropdown = async (wanted) => {
    for (let retry = 0; retry < 20; retry++) {
      const option = [...document.querySelectorAll('[role="option"], [role="menuitem"]')]
        .find((item) => item.textContent.trim() === wanted);
      if (option) {
        option.click();
        return true;
      }
      await wait(50);
    }
    return false;
  };
  const selectThreatField = async (label, fallbackIndex, wanted) => {
    const native = document.querySelectorAll("select")[fallbackIndex];
    if (native) return chooseNative(native, wanted);
    const combos = [...document.querySelectorAll('[role="combobox"]')];
    const combo = combos.find((item) => {
      const text = [item.textContent, item.getAttribute("aria-label"), item.getAttribute("title")]
        .filter(Boolean).join(" ");
      return text.includes(label);
    }) || combos[fallbackIndex];
    if (!combo) return false;
    if (combo.textContent.includes(wanted)) return true;
    combo.click();
    return chooseGoogleDropdown(wanted);
  };
  const timer = setInterval(async () => {
    if (filling) return;
    filling = true;
    attempts++;
    const fields = [...document.querySelectorAll("textarea")].filter((el) => el.name !== "g-recaptcha-response");
    const field = fields[0];
    if (field && detail && field.value !== detail) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(field, detail);
      fire(field);
    }
    // Combobox 0 adalah "Jenis Laporan" dan wajib dibiarkan tetap
    // "Halaman ini tidak aman". Hanya isi combobox ancaman (1) dan kategori (2).
    const threatReady = await selectThreatField("Jenis Ancaman", 1, "Software yang Tidak Diinginkan");
    const categoryReady = threatReady && await selectThreatField("Kategori Ancaman", 2, "Software Seluler yang Tidak Diinginkan");
    if ((field || !detail) && threatReady && categoryReady) clearInterval(timer);
    else if (attempts >= 60) clearInterval(timer);
    filling = false;
  }, 250);
})();

(() => {
  const detail = new URLSearchParams(location.search).get("srq_detail");
  if (!detail) return;
  let attempts = 0;
  const timer = setInterval(() => {
    attempts++;
    const fields = [...document.querySelectorAll("textarea")].filter((el) => el.name !== "g-recaptcha-response");
    const field = fields[0];
    if (field) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(field, detail);
      field.dispatchEvent(new Event("input", { bubbles: true }));
      field.dispatchEvent(new Event("change", { bubbles: true }));
      clearInterval(timer);
    } else if (attempts >= 40) clearInterval(timer);
  }, 250);
})();

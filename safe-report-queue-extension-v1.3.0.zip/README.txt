SAFE REPORT QUEUE COMPANION — CHROME

1. Ekstrak ZIP paket Safe Report Queue.
2. Buka chrome://extensions di Chrome.
3. Aktifkan Developer mode.
4. Klik Load unpacked.
5. Pilih folder chrome-extension.
6. Buka ulang website *.pages.dev milik Anda.

Extension hanya aktif pada website Pages Anda dan formulir resmi Google Safe Browsing.
Extension menyediakan dua mode: maksimal 100 tab dalam satu jendela atau 100 jendela Chrome terpisah. Keduanya mengisi Detail tambahan.
Jenis Ancaman otomatis dipilih menjadi Software yang Tidak Diinginkan.
Kategori Ancaman otomatis dipilih menjadi Software Seluler yang Tidak Diinginkan.
CAPTCHA serta tombol Kirim tetap dikerjakan manual.

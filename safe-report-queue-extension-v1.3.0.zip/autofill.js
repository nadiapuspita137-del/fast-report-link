(() => {
  const detail = new URLSearchParams(location.search).get("srq_detail");

  const waitFor = (find, timeout = 10000) => new Promise((resolve) => {
    const started = Date.now();
    const timer = setInterval(() => {
      const result = find();
      if (result || Date.now() - started >= timeout) {
        clearInterval(timer);
        resolve(result || null);
      }
    }, 200);
  });

  const text = (element) => (element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
  const fire = (element) => {
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  };

  async function fillDetail() {
    if (!detail) return;
    const field = await waitFor(() =>
      [...document.querySelectorAll("textarea")].find((element) => element.name !== "g-recaptcha-response")
    );
    if (!field) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
    setter?.call(field, detail);
    fire(field);
  }

  async function choose(index, wanted) {
    const control = await waitFor(() => {
      const controls = [...document.querySelectorAll('select,[role="combobox"]')]
        .filter((element) => element.offsetParent !== null);
      return controls[index] || null;
    });
    if (!control || text(control).includes(wanted)) return;

    if (control.tagName === "SELECT") {
      const option = [...control.options].find((item) => text(item).includes(wanted));
      if (!option) return;
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      setter?.call(control, option.value);
      fire(control);
      return;
    }

    control.click();
    const option = await waitFor(() =>
      [...document.querySelectorAll('[role="option"],mat-option,[role="menuitem"]')]
        .find((element) => element.offsetParent !== null && text(element).includes(wanted)),
      5000
    );
    option?.click();
  }

  (async () => {
    await fillDetail();
    await choose(1, "Software yang Tidak Diinginkan");
    await choose(2, "Software Seluler yang Tidak Diinginkan");
  })();
})();
